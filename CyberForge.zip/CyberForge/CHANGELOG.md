# Changelog

All notable changes to CyberForge will be documented in this file.

## [2.0.0] - 2026-07-21

### Added
- 18 security tools across reconnaissance, cryptography, web security, and network security
- Interactive CLI menu with single-tool CLI flags (`-t`, `-l`)
- Automatic JSON report generation
- Daily activity logs
- Cross-platform support (Linux, Windows, macOS)
- CyberForge Pro: Web-based security dashboard (HTML)

### Tools
- Network Scanner
- Port Scanner (30+ common ports)
- WHOIS Lookup
- DNS Reconnaissance (7 record types)
- Subdomain Enumerator (+ Certificate Transparency)
- Hash Generator/Cracker/Verifier
- Web Technology Detector
- Firewall Tester
- WiFi Scanner
- Password Strength Checker (with entropy + crack-time)
- Email Header Analyzer
- URL Expander & Checker
- Tor Checker
- IP Geolocation
- Cipher Tools (7 ciphers)
- SQL Injection Tester
- Web Crawler (with email/phone extraction)
- SSL/TLS Analyzer

### Notes
- Zero external Python dependencies — pure standard library
