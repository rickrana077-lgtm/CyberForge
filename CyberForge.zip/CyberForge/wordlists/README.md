# Wordlists

Drop your custom wordlists here for use with:

- **Hash Cracker** (Tool 06) — point it to your wordlist path when prompted
- **Subdomain Enumerator** (Tool 05) — built-in list by default
- **Password Checker** (Tool 10) — built-in common-password list by default

## Recommended free wordlists

- [SecLists](https://github.com/danielmiessler/SecLists) — the gold standard
- [rockyou.txt](https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt) — classic password dump

## Notes

- Plain `.txt` files, one entry per line
- Files in this directory are gitignored (except this README) to keep your repo clean
- Built-in wordlists in `utils/helpers.py` are always available
