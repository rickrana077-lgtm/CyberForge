<div align="center">

# 🔐 CyberForge — Advanced Security Toolkit

<img src="https://img.shields.io/badge/Version-2.0.0-cyan?style=for-the-badge" />
<img src="https://img.shields.io/badge/Python-3.8+-blue?style=for-the-badge&logo=python" />
<img src="https://img.shields.io/badge/License-MIT-green?style=for-the-badge" />
<img src="https://img.shields.io/badge/Platform-Linux%20%7C%20Windows%20%7C%20Mac-orange?style=for-the-badge" />
<img src="https://img.shields.io/badge/Dependencies-None-success?style=for-the-badge" />

```
    ██████╗██╗   ██╗██████╗ ███████╗██████╗
   ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
   ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝
   ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗
   ╚██████╗   ██║   ██████╔╝███████╗██║  ██║
    ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
         CyberForge - Advanced Security Toolkit v2.0
```

A comprehensive, Python-based cybersecurity toolkit for **penetration testing, security auditing, and network reconnaissance**. 18+ powerful security tools in a single, easy-to-use CLI — and **zero external dependencies**.

</div>

---

> ⚠️ **Disclaimer**: This tool is for **educational and authorized testing purposes only**. Unauthorized use against systems you do not own or have explicit permission to test is **illegal**. The developers assume no liability for misuse.

---

## ✨ Features

### 🔍 Reconnaissance
| # | Tool | Description |
|---|------|-------------|
| 01 | **Network Scanner** | Discover hosts on a network |
| 02 | **Port Scanner** | Identify open ports & services |
| 03 | **WHOIS Lookup** | Domain registration information |
| 04 | **DNS Recon** | DNS record enumeration (A/AAAA/MX/NS/TXT/CNAME/SOA) |
| 05 | **Subdomain Enum** | Find subdomains via wordlist + Certificate Transparency |
| 14 | **IP Geolocation** | Geo-locate any IP address |

### 🔐 Cryptography
| # | Tool | Description |
|---|------|-------------|
| 06 | **Hash Tool** | Generate, crack & verify hashes (MD5/SHA1/SHA256/SHA512/BLAKE2) |
| 10 | **Password Checker** | Strength analysis with entropy & crack-time estimation |
| 15 | **Cipher Tools** | Caesar, ROT13, Base64, Vigenère, XOR, Atbash, Binary/Hex/ASCII |

### 🌐 Web Security
| # | Tool | Description |
|---|------|-------------|
| 07 | **Web Tech Detector** | Detect technologies & missing security headers |
| 12 | **URL Checker** | Expand short URLs & detect phishing patterns |
| 16 | **SQLi Tester** | Test for SQL injection vulnerabilities |
| 17 | **Web Crawler** | Crawl websites, extract emails & links |
| 18 | **SSL/TLS Analyzer** | Analyze SSL/TLS certificates & cipher strength |

### 🛡️ Network Security
| # | Tool | Description |
|---|------|-------------|
| 08 | **Firewall Tester** | Test firewall rules & OS fingerprinting via TTL |
| 09 | **WiFi Scanner** | Scan nearby WiFi networks |
| 13 | **Tor Checker** | Check Tor status & test IPs against Tor exit list |
| 11 | **Email Analyzer** | Analyze email headers for spoofing indicators |

---

## 🚀 Quick Start

### Installation
```bash
# Clone the repo
git clone https://github.com/your-username/CyberForge.git
cd CyberForge

# No pip install needed — pure Python standard library!
python3 cyberforge.py
```

### One-Liner
```bash
git clone https://github.com/your-username/CyberForge.git && cd CyberForge && python3 cyberforge.py
```

### Run a Specific Tool
```bash
# Run a single tool without the menu
python3 cyberforge.py -t port_scanner
python3 cyberforge.py -t dns_recon
python3 cyberforge.py -t pass_checker

# List all tools
python3 cyberforge.py -l
```

### Import as a Module
```python
from tools import port_scanner, hash_tool, pass_checker

port_scanner()
hash_tool()
pass_checker()
```

---

## 📖 Usage

```text
  ┌─────────────────────────────────────────────┐
  │              🔐 MAIN MENU                   │
  └─────────────────────────────────────────────┘

  [01] 🔍 Network Scanner          [10] 🔑 Password Strength Checker
  [02] 🌐 Port Scanner             [11] 📧 Email Header Analyzer
  [03] 🕵️ WHOIS Lookup            [12] 🔗 URL Expander & Checker
  [04] 📡 DNS Reconnaissance       [13] 🧅 Tor Checker
  [05] 🖥️ Subdomain Enumerator     [14] 📋 IP Geolocation
  [06] 🔐 Hash Generator/Cracker   [15] 🧩 Cipher Tools
  [07] 📊 Web Technology Detector  [16] 💉 SQL Injection Tester
  [08] 🔥 Firewall Tester          [17] 🕷️ Web Crawler
  [09] 📡 WiFi Scanner             [18] 📦 SSL/TLS Analyzer

  [00] Exit
```

Pick a number, hit Enter, follow the prompts. It's that simple.

---

## 📁 Project Structure

```
CyberForge/
├── cyberforge.py          # Main entry point & CLI
├── tools/
│   └── __init__.py        # All 18 security tools
├── utils/
│   ├── __init__.py
│   ├── colors.py          # Terminal color definitions
│   └── helpers.py         # Validation, reporting, logging, wordlists
├── wordlists/             # (empty) drop your custom wordlists here
├── reports/               # Auto-generated JSON scan reports
├── logs/                  # Activity logs (one per day)
├── assets/                # Screenshots, images
├── requirements.txt       # Empty — no external deps!
├── LICENSE                # MIT
├── .gitignore
└── README.md
```

---

## 🔧 Requirements

- **Python 3.8+**
- **Zero external dependencies** — pure Python standard library
- Works on **Linux**, **Windows**, and **macOS**

### Optional System Packages (better experience)
```bash
# Debian / Ubuntu
sudo apt install whois dnsutils nmap

# macOS (Homebrew)
brew install whois bind nmap

# Arch Linux
sudo pacman -S whois bind-tools nmap
```

| Tool | Optional package |
|------|------------------|
| WHOIS Lookup | `whois` |
| DNS Recon | `dig` / `nslookup` |
| WiFi Scanner | `nmcli` (Linux) / `netsh` (Windows) |

---

## 📊 Reports & Logs

Every scan automatically saves a timestamped JSON report:

```
reports/
├── network_scan_20260721_103045.json
├── port_scan_20260721_103200.json
├── dns_recon_20260721_103500.json
├── ssl_analyze_20260721_104000.json
└── ...
```

Activity logs are written daily to `logs/cyberforge_YYYYMMDD.log`.

---

## 🖼️ Preview

```
╔══════════════════════════════════════════════════════════╗
║     ██████╗██╗   ██╗██████╗ ███████╗██████╗             ║
║    ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗            ║
║    ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝            ║
║    ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗            ║
║    ╚██████╗   ██║   ██████╔╝███████╗██║  ██║            ║
║     ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝            ║
║          CyberForge - Advanced Security Toolkit           ║
║                        v2.0.0                            ║
╚══════════════════════════════════════════════════════════╝
```

---

## 🤝 Contributing

Contributions are welcome! Here's how:

1. **Fork** the repository
2. Create a feature branch: `git checkout -b feature/new-tool`
3. Commit your changes: `git commit -m 'Add new security tool'`
4. Push to the branch: `git push origin feature/new-tool`
5. Open a **Pull Request**

### Adding a New Tool
1. Add your tool function to `tools/__init__.py`
2. Follow the existing naming convention (`snake_case`)
3. Add it to the menu in `cyberforge.py`
4. Update this README's feature table

---

## 📜 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

---

## ⚖️ Legal

- This tool is provided for **educational and authorized security testing only**
- Always obtain **written permission** before testing any system
- The developers are **not responsible** for any misuse or damage
- Unauthorized access to computer systems is **illegal** in most jurisdictions

---

## 🌟 Show Your Support

If CyberForge helped you, please consider giving it a ⭐ — it motivates me to keep adding more tools!

---

<div align="center">
  <strong>Built with 🔐 by the CyberForge Team</strong>
  <br>
  <em>Stay ethical. Stay legal. Stay curious.</em>
</div>
